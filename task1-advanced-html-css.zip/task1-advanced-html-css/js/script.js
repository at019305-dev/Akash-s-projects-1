document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("contactForm");
    const modal = document.getElementById("successModal");
    const closeModal = document.getElementById("closeModal");

    form.addEventListener("submit", (e) => {
        e.preventDefault();

        // Get values
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const message = document.getElementById("message").value;

        // Create object
        const formData = {
            name,
            email,
            message,
            date: new Date().toLocaleString()
        };

        // Get existing data
        let submissions = JSON.parse(localStorage.getItem("submissions")) || [];

        // Add new data
        submissions.push(formData);

        // Save back to localStorage
        localStorage.setItem("submissions", JSON.stringify(submissions));

        modal.style.display = "block";
        form.reset();
    });

    closeModal.addEventListener("click", () => {
        modal.style.display = "none";
    });

    window.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
        }
    });

    // Navbar
    const hamburger = document.getElementById("hamburger");
    const navLinks = document.getElementById("navLinks");

    hamburger.addEventListener("click", () => {
        navLinks.classList.toggle("active");
    });
});
